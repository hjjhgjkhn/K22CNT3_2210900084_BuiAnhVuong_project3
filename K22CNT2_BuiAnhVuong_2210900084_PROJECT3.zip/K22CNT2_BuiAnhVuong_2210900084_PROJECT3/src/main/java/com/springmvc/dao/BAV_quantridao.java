package com.springmvc.dao;

import com.springmvc.beans.Bav_quantri;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class BAV_quantridao {
    @Autowired
    private JdbcTemplate template;

    public void setTemplate(JdbcTemplate template) {
        this.template = template;
    }

    // Thêm tài khoản admin mới (Đăng ký)
    public int save(Bav_quantri p) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String hashedPassword = encoder.encode(p.getBav_MatKhau()); // Băm mật khẩu

        String sql = "INSERT INTO Bav_quantri (bav_TaiKhoan, bav_MatKhau, bav_TrangThai) VALUES (?, ?, ?)";
        return template.update(sql, p.getBav_TaiKhoan(), hashedPassword, p.isBav_TrangThai());
    }

    // Cập nhật thông tin admin
    public int update(Bav_quantri p) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String hashedPassword = encoder.encode(p.getBav_MatKhau()); // Băm mật khẩu mới

        String sql = "UPDATE Bav_quantri SET bav_TaiKhoan = ?, bav_MatKhau = ?, bav_TrangThai = ? WHERE id = ?";
        return template.update(sql, p.getBav_TaiKhoan(), hashedPassword, p.isBav_TrangThai(), p.getId());
    }

    // Xóa admin theo ID
    public int delete(int id) {
        String sql = "DELETE FROM Bav_quantri WHERE id = ?";
        return template.update(sql, id);
    }

    // Lấy thông tin admin theo ID
    public Bav_quantri getEmpById(int id) {
        String sql = "SELECT * FROM Bav_quantri WHERE id = ?";
        try {
            return template.queryForObject(sql, new Object[]{id}, new BeanPropertyRowMapper<>(Bav_quantri.class));
        } catch (EmptyResultDataAccessException e) {
            return null; // Không tìm thấy admin
        }
    }

    // Lấy danh sách tất cả admin
    public List<Bav_quantri> getEmployees() {
        String sql = "SELECT * FROM Bav_quantri";
        return template.query(sql, new RowMapper<Bav_quantri>() {
            public Bav_quantri mapRow(ResultSet rs, int row) throws SQLException {
                Bav_quantri e = new Bav_quantri();
                e.setId(rs.getInt("id"));
                e.setBav_TaiKhoan(rs.getString("bav_TaiKhoan"));
                e.setBav_MatKhau(rs.getString("bav_MatKhau"));
                e.setBav_TrangThai(rs.getBoolean("bav_TrangThai"));
                return e;
            }
        });
    }

    // Đăng nhập admin (kiểm tra mật khẩu bằng BCrypt)
    public Bav_quantri getAdminByUsernameAndPassword(String username, String password) {
        String sql = "SELECT * FROM Bav_quantri WHERE bav_TaiKhoan = ?";
        try {
            Bav_quantri admin = template.queryForObject(sql, new Object[]{username}, new BeanPropertyRowMapper<>(Bav_quantri.class));

            // Kiểm tra mật khẩu đã băm
            BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
            if (admin != null && encoder.matches(password, admin.getBav_MatKhau())) {
                return admin; // Đăng nhập thành công
            }
            return null; // Sai mật khẩu
        } catch (EmptyResultDataAccessException e) {
            return null; // Không tìm thấy tài khoản
        }
    }
}
