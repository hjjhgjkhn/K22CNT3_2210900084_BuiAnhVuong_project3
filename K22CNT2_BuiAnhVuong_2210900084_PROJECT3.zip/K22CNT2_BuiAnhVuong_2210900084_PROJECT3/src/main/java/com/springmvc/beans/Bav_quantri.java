package com.springmvc.beans;

public class Bav_quantri {
    private int id;
    private String bav_TaiKhoan;
    private String bav_MatKhau;
    private boolean bav_TrangThai;
    
    /**
     * @param id
     * @param bav_TaiKhoan
     * @param bav_MatKhau
     * @param bav_TrangThai
     */
    public Bav_quantri(int id, String bav_TaiKhoan, String bav_MatKhau, boolean bav_TrangThai) {
        super();
        this.id = id;
        this.bav_TaiKhoan = bav_TaiKhoan;
        this.bav_MatKhau = bav_MatKhau;
        this.bav_TrangThai = bav_TrangThai;
    }
    
    /**
     * 
     */
    public Bav_quantri() {
        super();
    }

    /**
     * 
     * @return the id
     */
    public int getId() {
        return id;
    }
    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
    /**
     * @return the bav_TaiKhoan
     */
    public String getBav_TaiKhoan() {
        return bav_TaiKhoan;
    }
    /**
     * @param bav_TaiKhoan the bav_TaiKhoan to set
     */
    public void setBav_TaiKhoan(String bav_TaiKhoan) {
        this.bav_TaiKhoan = bav_TaiKhoan;
    }
    /**
     * @return the bav_MatKhau
     */
    public String getBav_MatKhau() {
        return bav_MatKhau;
    }
    /**
     * @param bav_MatKhau the bav_MatKhau to set
     */
    public void setBav_MatKhau(String bav_MatKhau) {
        this.bav_MatKhau = bav_MatKhau;
    }
    /**
     * @return the bav_TrangThai
     */
    public boolean isBav_TrangThai() {
        return bav_TrangThai;
    }
    /**
     * @param bav_TrangThai the bav_TrangThai to set
     */
    public void setBav_TrangThai(boolean bav_TrangThai) {
        this.bav_TrangThai = bav_TrangThai;
    }
}
